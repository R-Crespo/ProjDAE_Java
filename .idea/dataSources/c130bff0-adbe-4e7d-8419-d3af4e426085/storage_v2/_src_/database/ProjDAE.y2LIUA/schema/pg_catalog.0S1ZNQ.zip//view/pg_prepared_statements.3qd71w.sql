create view pg_prepared_statements
            (name, statement, prepare_time, parameter_types, result_types, from_sql, generic_plans, custom_plans) as
SELECT name,
       statement,
       prepare_time,
       parameter_types,
       result_types,
       from_sql,
       generic_plans,
       custom_plans
FROM pg_prepared_statement() p(name, statement, prepare_time, parameter_types, result_types, from_sql, generic_plans,
                               custom_plans);

alter table pg_prepared_statements
    owner to postgres;

grant select on pg_prepared_statements to public;

